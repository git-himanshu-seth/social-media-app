import AppRoutes from "../pages";
import { Routes, Route, useNavigate } from "react-router-dom";
import firebaseAuthManager from "../utilis/services/firebase";
import { useEffect, useState } from "react";

const DefaultRoutes = () => {
  const [isUser, setIsUser] = useState();
  const navigate = useNavigate();

  useEffect(() => {
    setIsUser(firebaseAuthManager.isUser);
  }, []);
  useEffect(() => {
    setIsUser(firebaseAuthManager.isUser);
  }, [firebaseAuthManager.isUser]);
  return (
    <div>
      <Routes>
        {AppRoutes.length > 0 &&
          AppRoutes.map(({ id, path, Component, isAuthenticated }) => {
            if (isAuthenticated && !isUser) {
              // Redirect to login if user is not authenticated
              navigate("madala/");
              return null; // Render nothing for this route
            }
            return <Route path={path} element={<Component />} key={id} />;
          })}
      </Routes>
    </div>
  );
};

export default DefaultRoutes;
